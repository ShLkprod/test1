# Bad folding when single character ')' in SCE_RB_STRING_QW #132
%W(#{1 + 1})

