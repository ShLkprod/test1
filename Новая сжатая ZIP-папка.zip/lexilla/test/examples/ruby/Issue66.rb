# Test that final \n in indented heredoc (2nd example) is styled as SCE_RB_HERE_Q not SCE_RB_HERE_DELIM
<<T
X
T

<<-T
X
T
